# TriPeaks PwPD — Solvable-Deal Module (board 3p4r28)

Bundled deal generator for the accessible TriPeaks game (PRD v2 §5). Ships
**inside the game client** — no separate service, no network call. Every deal
it returns has at least one winning line, proven by an exact memoized
depth-first solver.

Zero dependencies. Files: `solver.js` (solver + generator — the only file the
game needs), `test.js` (Node-only: invariants, edge cases, difficulty stats).

## Use in the game client

```js
const { generateSolvableDeal, coveredBy, STOCK_SIZE, WILD_CHANCE } = require("./solver.js");
// or convert to an ES module: export { ... } — do not change the logic

const { deal } = generateSolvableDeal("auto");   // "auto" | "always" | "never"
// deal = { deal_id, verified_solvable: true, tableau[28], stock[23], waste }
// stock: LAST element is drawn first. "WILD" appears at most once, only in stock.
```

- Import `coveredBy` for the game's own uncovered/legal-move logic rather than
  re-typing the coverage graph (PRD acceptance criterion 2).
- ~15–25 ms per deal on a laptop; call synchronously on "New deal" behind the
  deal animation, or in a Web Worker if preferred.
- Throws only after 500 unsolvable shuffles in a row (practically never at a
  97.9 % solvable rate) — catch and fall back to an unverified shuffle.

## Test

```
node test.js          # ~30 s; must pass before wiring into the game
```

## Board indices (PRD v2 §3.1–3.2)

Row 0 apexes: 0,1,2 · Row 1: 3–8 · Row 2: 9–17 · Row 3 (bottom, face-up): 18–27.
`coveredBy` in `solver.js` is the normative coverage graph.

## Measured characteristics (container benchmarks, 1,000 random deals each)

| Configuration | Optimally solvable | Greedy-bot win rate | Solve time |
|---|---|---|---|
| 28 cards, stock 23, no wild | 97.9 % | 48.9 % | ~14 ms |
| 28 cards, stock 23, with wild | 99.6 % | 53.9 % | ~10 ms |

- Greedy-bot win rate (~49 %) matches the classic-TriPeaks reference used to
  tune the earlier 19-card board, so perceived difficulty is unchanged.
- Nearly every random 28-card deal is solvable by perfect play, so
  verification rejects only ~2 % of shuffles (avg 1.02 attempts, ~22 ms per
  verified deal). The `verified_solvable` guarantee is
  therefore mostly a "no dead deals" promise; the more useful future lever is
  grading deals by solver effort / forced draws (hook noted below).
- Wild `auto` produced a wildcard in 40.3 % of 300 deals (target 40 %).
- Contract invariants tested: 28 tableau + 23 stock entries, no duplicates,
  at most one WILD, WILD never in tableau/waste, A↔K wrap-around.

## Tuning hooks (solver.js)

- `WILD_CHANCE` (0.4), `STOCK_SIZE` (23) — the game should read these from the module rather than duplicating them.
- Difficulty tiers later: filter deals by solver effort (memo size) or by the
  minimum number of stock draws in the best line, to grade easy/medium/hard.
